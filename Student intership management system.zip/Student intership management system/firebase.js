// Import Firebase
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-app.js";

import { 
getAuth, 
createUserWithEmailAndPassword,
signOut
} 
from "https://www.gstatic.com/firebasejs/10.12.5/firebase-auth.js";

import { getFirestore } from "https://www.gstatic.com/firebasejs/10.12.5/firebase-firestore.js";

// Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyB9iYNUEbmM3Ng6811HRw_r4r_iWP7m2Lc",
  authDomain: "sims-87a59.firebaseapp.com",
  projectId: "sims-87a59",
  storageBucket: "sims-87a59.firebasestorage.app",
  messagingSenderId: "957103504527",
  appId: "1:957103504527:web:7d6a6c9f17228a7ac5c4fa"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Export
export const auth = getAuth(app);
const logoutBtn = document.getElementById("logoutBtn");

if(logoutBtn){

logoutBtn.addEventListener("click",()=>{

signOut(auth)
.then(()=>{
alert("Logout Successfully");
window.location.href="login.html";
})
.catch((error)=>{
console.log(error);
});

});

}

signOut(auth)
.then(()=>{
alert("Logout Successfully");
window.location.href="login.html";
})
.catch((error)=>{
console.log(error);
});

});
export const db = getFirestore(app);