@echo off
title Student Internship Management System
cd /d "%~dp0"
echo Starting Student Internship Management System...
start "" http://127.0.0.1:5000/
python app.py
pause
